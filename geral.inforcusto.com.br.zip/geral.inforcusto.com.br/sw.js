/* Inforcusto Geral Service Worker - PWA raiz v7 */
const CACHE_NAME = 'inforcusto-geral-pwa7-raiz';
const OFFLINE_URL = '/offline.html';

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil((async () => {
    try {
      const cache = await caches.open(CACHE_NAME);
      await cache.addAll([OFFLINE_URL, '/icon-192.png', '/icon-512.png', '/icons/maskable-512.png']);
    } catch (e) {}
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    try {
      const keys = await caches.keys();
      await Promise.all(keys.map((key) => key === CACHE_NAME ? Promise.resolve() : caches.delete(key)));
    } catch (e) {}
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith('/data/') || url.pathname.endsWith('/config.php')) return;

  if (event.request.mode === 'navigate') {
    event.respondWith(fetch(event.request).catch(async () => {
      return (await caches.match(OFFLINE_URL)) || new Response('Offline', {status: 503, headers: {'Content-Type':'text/plain; charset=utf-8'}});
    }));
    return;
  }

  event.respondWith(fetch(event.request).then((response) => {
    if (response && response.ok) {
      const copy = response.clone();
      caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy)).catch(() => {});
    }
    return response;
  }).catch(() => caches.match(event.request)));
});

self.addEventListener('push', (event) => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; }
  catch (e) { data = {title:'Inforcusto Geral', body: event.data ? event.data.text() : 'Nova notificação', url:'/'}; }
  event.waitUntil(self.registration.showNotification(data.title || 'Inforcusto Geral', {
    body: data.body || 'Nova notificação.',
    icon: data.icon || '/icon-192.png',
    badge: data.badge || '/icon-192.png',
    data: {url: data.url || '/'},
    tag: data.tag || ('inforcusto-' + Date.now()),
    renotify: true,
    vibrate: [180,80,180]
  }));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const targetUrl = new URL((event.notification.data && event.notification.data.url) || '/', self.location.origin).href;
  event.waitUntil((async () => {
    const allClients = await clients.matchAll({type:'window', includeUncontrolled:true});
    for (const client of allClients) {
      try {
        if ('focus' in client) {
          await client.focus();
          if ('navigate' in client) return client.navigate(targetUrl);
          return;
        }
      } catch(e) {}
    }
    if (clients.openWindow) return clients.openWindow(targetUrl);
  })());
});
