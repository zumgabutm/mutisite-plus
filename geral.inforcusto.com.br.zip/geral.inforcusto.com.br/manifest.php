<?php
header('Content-Type: application/manifest+json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0');
readfile(__DIR__ . '/manifest.json');
