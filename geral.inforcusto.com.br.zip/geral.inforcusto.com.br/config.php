<?php
session_start();
$DATA_DIR=__DIR__.'/data';
if(!is_dir($DATA_DIR)) mkdir($DATA_DIR,0755,true);
$DATA_FILE=$DATA_DIR.'/sites.json';
if(!file_exists($DATA_FILE)) file_put_contents($DATA_FILE,'[]');
$UPLOAD_DIR=__DIR__.'/fotos';
if(!is_dir($UPLOAD_DIR)) mkdir($UPLOAD_DIR,0755,true);
$ADMIN_USER='admin';
$ADMIN_PASSWORD='Jecielp559@#$%';
function sort_sites_fixed($arr){
  if(!is_array($arr)) return [];
  foreach($arr as $k=>$item){
    if(!is_array($item)) $item=[];
    $item['_order']=$k;
    $arr[$k]=$item;
  }
  usort($arr,function($a,$b){
    $fa=!empty($a['fixed']) ? 1 : 0;
    $fb=!empty($b['fixed']) ? 1 : 0;
    if($fa !== $fb) return $fb <=> $fa;
    return ($a['_order'] ?? 0) <=> ($b['_order'] ?? 0);
  });
  foreach($arr as &$item){ unset($item['_order']); }
  unset($item);
  return $arr;
}
function read_sites(){ global $DATA_FILE; $json=@file_get_contents($DATA_FILE); $arr=@json_decode($json,true); return is_array($arr)?sort_sites_fixed($arr):[];}
function write_sites($arr){ global $DATA_FILE; $arr=sort_sites_fixed($arr); $data=json_encode($arr,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT); file_put_contents($DATA_FILE,$data,LOCK_EX);}
function is_logged(){ return !empty($_SESSION['admin_logged']);}
function login_user($u,$p){ global $ADMIN_USER,$ADMIN_PASSWORD; if($u===$ADMIN_USER && $p===$ADMIN_PASSWORD){ $_SESSION['admin_logged']=true; return true;} return false;}
function logout_user(){ session_unset(); session_destroy();}
function generate_csrf(){ if(empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(16)); return $_SESSION['csrf'];}
function check_csrf($t){ return !empty($_SESSION['csrf']) && hash_equals($_SESSION['csrf'],$t);}
function upload_icon_file($f){ global $UPLOAD_DIR; if(!isset($f) || $f['error']!==UPLOAD_ERR_OK) return false; if($f['size']>2*1024*1024) return false; $img=@getimagesize($f['tmp_name']); if(!$img) return false; $ext=image_type_to_extension($img[2],false); $name=bin2hex(random_bytes(8)).'.'.$ext; $dest=$UPLOAD_DIR.'/'.$name; if(move_uploaded_file($f['tmp_name'],$dest)) return $name; return false;}
function sanitize($s){ return trim($s);}
