<?php
require 'config.php';

if(isset($_GET['action']) && $_GET['action'] === 'logout'){
  logout_user();
  header('Location: admin.php');
  exit;
}

if($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'login'){
  $u = $_POST['user'] ?? '';
  $p = $_POST['pass'] ?? '';
  if(login_user($u, $p)){
    header('Location: admin.php');
    exit;
  }
  $err = 'Usuário ou senha inválidos';
}

if(!is_logged()):
?><!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
  <meta name="theme-color" content="#111827">
  <title>Admin | Inforcusto Geral</title>
  <meta name="application-name" content="Inforcusto Geral">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-title" content="Inforcusto Geral">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="msapplication-TileColor" content="#111827">
  <link rel="canonical" href="https://geral.inforcusto.com.br/">
  <link rel="manifest" href="/manifest.json">
  <link rel="apple-touch-icon" href="/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="192x192" href="/icon-192.png">
  <link rel="stylesheet" href="/admin.css?v=fixado-css-20260612-v7">
</head>
<body class="login-page">
  <main class="login-wrap">
    <form method="post" class="login-card" autocomplete="on">
      <span class="brand-mark">I</span>
      <h1>Admin Inforcusto</h1>
      <p>Entre para cadastrar, editar ou remover os serviços do painel geral.</p>
      <?php if(!empty($err)): ?><div class="err"><?=htmlspecialchars($err, ENT_QUOTES, 'UTF-8')?></div><?php endif; ?>
      <label>Usuário<input name="user" placeholder="Digite o usuário" required autocomplete="username"></label>
      <label>Senha<input name="pass" type="password" placeholder="Digite a senha" required autocomplete="current-password"></label>
      <input type="hidden" name="action" value="login">
      <button type="submit">Entrar</button>
      <a class="back-home" href="index.php">Voltar ao painel</a>
    </form>
  </main>
  <script src="/pwa-register.js?v=pwa-fim-base-20260612-v5" defer></script>
</body>
</html><?php exit; endif;

$sites = read_sites();
$notice = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
  $action = $_POST['action'] ?? '';

  if($action === 'add' && check_csrf($_POST['csrf'] ?? '')){
    $entry = [
      'name' => sanitize($_POST['name'] ?? ''),
      'link' => sanitize($_POST['link'] ?? ''),
      'icon_url' => sanitize($_POST['icon_url'] ?? ''),
      'icon_file' => null,
      'splash' => sanitize($_POST['splash'] ?? ''),
      'fixed' => !empty($_POST['fixed']),
      'pulse' => !empty($_POST['pulse'])
    ];
    if(isset($_FILES['icon_file']) && $_FILES['icon_file']['error'] === UPLOAD_ERR_OK){
      $up = upload_icon_file($_FILES['icon_file']);
      if($up) $entry['icon_file'] = $up;
    }
    $sites[] = $entry;
    write_sites($sites);
    header('Location: admin.php?ok=add');
    exit;
  }

  if($action === 'delete' && check_csrf($_POST['csrf'] ?? '')){
    $idx = (int)($_POST['idx'] ?? -1);
    if(isset($sites[$idx])){
      if(!empty($sites[$idx]['icon_file']) && file_exists('fotos/'.$sites[$idx]['icon_file'])){
        @unlink('fotos/'.$sites[$idx]['icon_file']);
      }
      array_splice($sites, $idx, 1);
      write_sites($sites);
    }
    header('Location: admin.php?ok=delete');
    exit;
  }

  if($action === 'update' && check_csrf($_POST['csrf'] ?? '')){
    $idx = (int)($_POST['idx'] ?? -1);
    if(isset($sites[$idx])){
      $sites[$idx]['name'] = sanitize($_POST['name'] ?? '');
      $sites[$idx]['link'] = sanitize($_POST['link'] ?? '');
      $sites[$idx]['icon_url'] = sanitize($_POST['icon_url'] ?? '');
      $sites[$idx]['splash'] = sanitize($_POST['splash'] ?? '');
      $sites[$idx]['fixed'] = !empty($_POST['fixed']);
      $sites[$idx]['pulse'] = !empty($_POST['pulse']);
      if(isset($_FILES['icon_file']) && $_FILES['icon_file']['error'] === UPLOAD_ERR_OK){
        $up = upload_icon_file($_FILES['icon_file']);
        if($up) $sites[$idx]['icon_file'] = $up;
      }
      write_sites($sites);
    }
    header('Location: admin.php?ok=update');
    exit;
  }
}

if(isset($_GET['ok'])){
  $messages = ['add'=>'Serviço adicionado com sucesso.','update'=>'Alterações salvas com sucesso.','delete'=>'Serviço removido com sucesso.'];
  $notice = $messages[$_GET['ok']] ?? '';
}

$csrf = generate_csrf();
$edit = null;
if(isset($_GET['edit'])){
  $e = (int)$_GET['edit'];
  if(isset($sites[$e])) $edit = ['idx'=>$e] + $sites[$e];
}
$totalSites = count($sites);
?><!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
  <meta name="theme-color" content="#111827">
  <title>Painel Admin | Inforcusto Geral</title>
  <meta name="application-name" content="Inforcusto Geral">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-title" content="Inforcusto Geral">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="msapplication-TileColor" content="#111827">
  <link rel="canonical" href="https://geral.inforcusto.com.br/">
  <link rel="manifest" href="/manifest.json">
  <link rel="apple-touch-icon" href="/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="192x192" href="/icon-192.png">
  <link rel="stylesheet" href="/admin.css?v=fixado-css-20260612-v7">
</head>
<body>
<header class="adm-top">
  <a class="adm-brand" href="index.php">
    <span class="brand-mark">I</span>
    <span><strong>Inforcusto</strong><small>Admin Geral</small></span>
  </a>
  <nav class="adm-actions" aria-label="Ações do painel">
    <a href="index.php">Ver painel</a>
    <a href="admin.php?action=logout">Sair</a>
  </nav>
</header>

<main class="adm-main">
  <section class="dashboard">
    <div class="dash-card highlight">
      <small>Total cadastrado</small>
      <strong><?=$totalSites?></strong>
      <span>serviço<?=$totalSites === 1 ? '' : 's'?></span>
    </div>
    <div class="dash-card">
      <small>Status</small>
      <strong>Online</strong>
      <span>PWA instalado no domínio geral.inforcusto.com.br</span>
    </div>
    <div class="dash-card">
      <small>Dados</small>
      <strong>JSON</strong>
      <span>Salvando em data/sites.json</span>
    </div>
  </section>

  <?php if($notice): ?><div class="notice"><?=htmlspecialchars($notice, ENT_QUOTES, 'UTF-8')?></div><?php endif; ?>

  <section class="adm-layout">
    <section class="adm-form panel-card">
      <div class="panel-title">
        <p><?=$edit ? 'Atualização' : 'Novo cadastro'?></p>
        <h1><?=$edit ? 'Editar serviço' : 'Adicionar serviço'?></h1>
      </div>
      <form method="post" enctype="multipart/form-data">
        <label>Nome do serviço<input name="name" value="<?=$edit ? htmlspecialchars($edit['name'] ?? '', ENT_QUOTES, 'UTF-8') : ''?>" required placeholder="Ex: Painel de clientes"></label>
        <label>Link de acesso<input name="link" value="<?=$edit ? htmlspecialchars($edit['link'] ?? '', ENT_QUOTES, 'UTF-8') : ''?>" required placeholder="https://..."></label>
        <label>Ícone por URL<input name="icon_url" value="<?=$edit ? htmlspecialchars($edit['icon_url'] ?? '', ENT_QUOTES, 'UTF-8') : ''?>" placeholder="https://..."></label>
        <label>Ou enviar ícone<input type="file" name="icon_file" accept="image/*"></label>
        <label>Descrição / texto splash<textarea name="splash" rows="4" placeholder="Explique para que serve esse serviço"><?=$edit ? htmlspecialchars($edit['splash'] ?? '', ENT_QUOTES, 'UTF-8') : ''?></textarea></label>
        <label class="check-line"><input type="checkbox" name="fixed" value="1" <?=($edit && !empty($edit['fixed'])) ? 'checked' : ''?>><span>Fixar no topo da página inicial</span></label>
        <label class="check-line"><input type="checkbox" name="pulse" value="1" <?=($edit && !empty($edit['pulse'])) ? 'checked' : ''?>><span>Destacar com efeito pulsando na página inicial</span></label>
        <input type="hidden" name="csrf" value="<?=$csrf?>">
        <input type="hidden" name="action" value="<?=$edit ? 'update' : 'add'?>">
        <?php if($edit): ?><input type="hidden" name="idx" value="<?=$edit['idx']?>"><?php endif; ?>
        <div class="form-actions">
          <button type="submit"><?=$edit ? 'Salvar alterações' : 'Adicionar serviço'?></button>
          <?php if($edit): ?><a href="admin.php">Cancelar edição</a><?php endif; ?>
        </div>
      </form>
    </section>

    <section class="adm-list panel-card">
      <div class="panel-title row">
        <div>
          <p>Gerenciamento</p>
          <h2>Sites cadastrados</h2>
        </div>
      </div>
      <?php if(empty($sites)): ?>
        <div class="empty-admin">Nenhum serviço cadastrado ainda.</div>
      <?php else: ?>
        <div class="table-wrap">
          <table>
            <thead><tr><th>#</th><th>Serviço</th><th>Fixado</th><th>Destaque</th><th>Link</th><th>Ícone</th><th>Ações</th></tr></thead>
            <tbody>
            <?php foreach($sites as $i=>$s): ?>
              <tr>
                <td data-label="#"><?=$i+1?></td>
                <td data-label="Serviço"><strong><?=htmlspecialchars($s['name'] ?? '', ENT_QUOTES, 'UTF-8')?></strong><small><?=htmlspecialchars($s['splash'] ?? '', ENT_QUOTES, 'UTF-8')?></small></td>
                <td data-label="Fixado"><?php if(!empty($s['fixed'])): ?><span class="fixed-pill">Fixo</span><?php else: ?><span class="muted">Normal</span><?php endif; ?></td>
                <td data-label="Destaque"><?php if(!empty($s['pulse'])): ?><span class="fixed-pill pulse-pill">Pulsando</span><?php else: ?><span class="muted">Normal</span><?php endif; ?></td>
                <td data-label="Link"><a class="table-link" href="<?=htmlspecialchars($s['link'] ?? '#', ENT_QUOTES, 'UTF-8')?>" target="_blank" rel="noopener noreferrer"><?=htmlspecialchars($s['link'] ?? '#', ENT_QUOTES, 'UTF-8')?></a></td>
                <td data-label="Ícone">
                  <?php if(!empty($s['icon_file'])): ?><img src="fotos/<?=htmlspecialchars($s['icon_file'], ENT_QUOTES, 'UTF-8')?>" class="mini" alt="Ícone">
                  <?php elseif(!empty($s['icon_url'])): ?><img src="<?=htmlspecialchars($s['icon_url'], ENT_QUOTES, 'UTF-8')?>" class="mini" alt="Ícone">
                  <?php else: ?><span class="muted">Sem ícone</span><?php endif; ?>
                </td>
                <td data-label="Ações" class="actions-cell">
                  <a class="edit" href="admin.php?edit=<?=$i?>">Editar</a>
                  <form method="post">
                    <input type="hidden" name="csrf" value="<?=$csrf?>">
                    <input type="hidden" name="idx" value="<?=$i?>">
                    <input type="hidden" name="action" value="delete">
                    <button class="delete" type="submit" onclick="return confirm('Excluir este serviço?')">Excluir</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php endif; ?>
    </section>
  </section>
</main>
<script src="/pwa-register.js?v=pwa-fim-base-20260612-v5" defer></script>
</body>
</html>
