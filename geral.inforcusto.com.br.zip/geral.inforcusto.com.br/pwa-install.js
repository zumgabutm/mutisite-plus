/* Registro PWA raiz v7 - simples igual ao modelo funcional */
if ('serviceWorker' in navigator) {
  window.addEventListener('load', function() {
    navigator.serviceWorker.register('/sw.js?v=pwa7-raiz', { scope: '/' })
      .then(function(reg) { console.log('PWA OK', reg.scope); })
      .catch(function(err) { console.log('PWA ERRO', err); });
  });
}
