<?php
require 'config.php';

$sites = read_sites();

/*
  Mantém a ordem original dentro de cada grupo,
  mas mostra primeiro os serviços marcados como fixos no admin.
*/
if(is_array($sites) && !empty($sites)){
  foreach($sites as $k => $site){
    $sites[$k]['_ordem_original'] = $k;
  }

  usort($sites, function($a, $b){
    $af = !empty($a['fixed']) ? 1 : 0;
    $bf = !empty($b['fixed']) ? 1 : 0;

    if($af !== $bf){
      return $bf <=> $af;
    }

    return ($a['_ordem_original'] ?? 0) <=> ($b['_ordem_original'] ?? 0);
  });
}

$totalSites = count($sites);
?>
<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
  <meta name="theme-color" content="#111827">
  <meta name="description" content="Painel geral Inforcusto com acesso rápido aos principais sistemas e serviços.">
  <title>Inforcusto Geral</title>
  <meta name="application-name" content="Inforcusto Geral">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-title" content="Inforcusto Geral">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="msapplication-TileColor" content="#111827">
  <link rel="canonical" href="https://geral.inforcusto.com.br/">
  <link rel="manifest" href="/manifest.json?v=pwa7-raiz">
  <link rel="apple-touch-icon" href="/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="192x192" href="/icon-192.png">
  <link rel="stylesheet" href="/index.css?v=netflix-pulse-20260612-v1">

<script>
(function(){
  // PWA raiz: registro simples, igual ao projeto que instala, sem bloquear o ícone nativo do Chrome.
  if (!('serviceWorker' in navigator)) return;
  window.addEventListener('load', function(){
    navigator.serviceWorker.register('/sw.js?v=pwa7-raiz', {scope: '/'})
      .then(function(reg){ console.log('PWA Inforcusto OK:', reg.scope); })
      .catch(function(err){ console.log('PWA Inforcusto ERRO:', err); });
  });
})();
</script>
</head>
<body>
  <div class="app-shell">
    <header class="hero">
      <nav class="nav-bar" aria-label="Topo do painel">
        <a class="brand" href="./" aria-label="Inforcusto Geral">
          <span class="brand-mark">I</span>
          <span>
            <strong>Inforcusto</strong>
            <small>Painel Geral</small>
          </span>
        </a>
      </nav>

      <section class="hero-content" aria-labelledby="hero-title">
        <div>
          <p class="eyebrow">Acesso rápido e organizado</p>
          <h1 id="hero-title">Tudo do Inforcusto em um só lugar.</h1>
          <p class="hero-text">Escolha um painel, loja ou plataforma e acesse com segurança.</p>
          <div class="search-card" role="search">
            <span aria-hidden="true">⌕</span>
            <input type="search" id="site-search" placeholder="Pesquisar por nome do serviço..." autocomplete="off">
          </div>
        </div>
        <aside class="hero-panel" aria-label="Resumo do painel">
          <span class="status-dot"></span>
          <strong><?=$totalSites?></strong>
          <small>Painel no sistema</small>
        </aside>
      </section>
    </header>

    <main class="main-content">
      <div class="section-head">
        <div>
          <p class="eyebrow dark">Painel</p>
          <h2>Paineis Disponivel</h2>
        </div>
        <span class="count-pill" id="result-count"><?=$totalSites?> Painel<?=$totalSites === 1 ? '' : 's'?></span>
      </div>

      <?php if(empty($sites)): ?>
        <section class="empty-state">
          <h2>Nenhum serviço cadastrado ainda</h2>
          <p>Nenhum serviço foi cadastrado ainda.</p>
        </section>
      <?php else: ?>
        <section class="grid" id="site-grid" aria-live="polite">
          <?php foreach($sites as $s):
            $icon = !empty($s['icon_file']) ? 'fotos/'.rawurlencode($s['icon_file']) : ($s['icon_url'] ?? '');
            $nameRaw = $s['name'] ?? 'Sem nome';
            $linkRaw = $s['link'] ?? '#';
            $splashRaw = $s['splash'] ?? '';
            $name = htmlspecialchars($nameRaw, ENT_QUOTES, 'UTF-8');
            $link = htmlspecialchars($linkRaw, ENT_QUOTES, 'UTF-8');
            $splash = htmlspecialchars($splashRaw, ENT_QUOTES, 'UTF-8');

            $cardClass = 'card';
            if(!empty($s['fixed'])){
              $cardClass .= ' is-fixed';
            }
            if(!empty($s['pulse'])){
              $cardClass .= ' pulse-card';
            }
          ?>
          <article class="<?=$cardClass?>" tabindex="0" role="button" data-link="<?=$link?>" data-name="<?=$name?>" data-desc="<?=$splash?>">
            <?php if(!empty($s['fixed'])): ?><span class="fixed-badge">★ Pro</span><?php endif; ?>
            <div class="card-icon-wrap">
              <?php if(!empty($icon)): ?>
                <img src="<?=htmlspecialchars($icon, ENT_QUOTES, 'UTF-8')?>" alt="<?=$name?>" class="card-icon" loading="lazy" onerror="this.src='/icons/icon-192.png'">
              <?php else: ?>
                <img src="/icons/icon-192.png" alt="<?=$name?>" class="card-icon" loading="lazy">
              <?php endif; ?>
            </div>
            <div class="card-body">
              <h3 class="card-title"><?=$name?></h3>
              <p class="card-desc"><?=$splash ?: 'Acesse este serviço pelo painel geral.'?></p>
            </div>
            <span class="card-action">Abrir</span>
          </article>
          <?php endforeach; ?>
        </section>
      <?php endif; ?>
    </main>
  </div>

  <div id="modal" class="modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="m-title">
    <div class="modal-card" role="document">
      <button id="m-cancel-x" class="modal-close" type="button" aria-label="Fechar">×</button>
      <span class="modal-badge">Confirmar acesso</span>
      <h2 id="m-title"></h2>
      <p id="m-desc"></p>
      <div class="modal-actions">
        <a id="m-visit" href="#" target="_blank" rel="noopener noreferrer">Visitar site</a>
        <button id="m-cancel" type="button">Cancelar</button>
      </div>
    </div>
  </div>

  <footer class="footer">
    <span>© <?=date('Y')?> Inforcusto</span>
    <span>by.inforcusto</span>
  </footer>

<script>
(function(){
  var grid = document.getElementById('site-grid');
  var searchInput = document.getElementById('site-search');
  var resultCount = document.getElementById('result-count');
  var modal = document.getElementById('modal');
  var mTitle = document.getElementById('m-title');
  var mDesc = document.getElementById('m-desc');
  var mVisit = document.getElementById('m-visit');
  var mCancel = document.getElementById('m-cancel');
  var mCancelX = document.getElementById('m-cancel-x');

  function normalizeText(text){
    return (text || '').toString().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  }

  function openModal(card){
    var link = card.getAttribute('data-link') || '#';
    var name = card.getAttribute('data-name') || 'Serviço';
    var desc = card.getAttribute('data-desc') || 'Acesse este serviço pelo painel geral.';
    mTitle.textContent = name;
    mDesc.textContent = desc;
    mVisit.setAttribute('href', link);
    modal.classList.add('open');
    modal.setAttribute('aria-hidden', 'false');
    mVisit.focus();
  }

  function closeModal(){
    modal.classList.remove('open');
    modal.setAttribute('aria-hidden', 'true');
  }

  if(grid){
    grid.querySelectorAll('.card').forEach(function(card){
      card.addEventListener('click', function(){ openModal(card); });
      card.addEventListener('keydown', function(e){
        if(e.key === 'Enter' || e.key === ' '){
          e.preventDefault();
          openModal(card);
        }
      });
    });
  }

  if(searchInput && grid){
    searchInput.addEventListener('input', function(){
      var term = normalizeText(searchInput.value);
      var visible = 0;
      grid.querySelectorAll('.card').forEach(function(card){
        var haystack = normalizeText((card.getAttribute('data-name') || '') + ' ' + (card.getAttribute('data-desc') || ''));
        var show = haystack.indexOf(term) !== -1;
        card.hidden = !show;
        if(show) visible++;
      });
      if(resultCount){
        resultCount.textContent = visible + ' resultado' + (visible === 1 ? '' : 's');
      }
    });
  }

  [mCancel, mCancelX].forEach(function(btn){
    if(btn) btn.addEventListener('click', closeModal);
  });
  if(modal){
    modal.addEventListener('click', function(e){ if(e.target === modal) closeModal(); });
  }
  document.addEventListener('keydown', function(e){ if(e.key === 'Escape') closeModal(); });
})();
</script>
</body>
</html>
